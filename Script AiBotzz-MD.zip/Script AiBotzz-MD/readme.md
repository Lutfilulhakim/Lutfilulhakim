<p align="center">
    <img src="https://telegra.ph/file/0aa23c7f060e0919e52cf.jpg" width="100%" style="margin-left: auto;margin-right: auto;display: block;">
    </p>
    <h1 align="center">Vin - MD</h1>

## BACA DULU SEBELUM PAKAI ##
- Ubah Informasi di Config.js
- Support Panel, Termux & replit
- Pastiakan Kamu Sudah Subrek Chanel Gua
- Harap Manuruh Credit Jika Ingin Recode Jika Tidak Di Pastikan Tidak Ada Update Lagi Ke Versi Selanjutnya.

### Sedikit Tentang Bot
- ✔️ | **Simple** 
- ✔️ | **No Button** 
- ✔️ | **Multi Device** 
- ✔️ | **Work All Fitur**
- ✔️ | **No Apikey**
- ---------
### Fitur Yang Dimiliki
- ✔️ | Tools 
- ✔️ | Remini
- ✔️ | Quotes
- ✔️ | Confess
- ✔️ | Chat Gpt
- ✔️ | Werewolf Games
- ✔️ | And Others
- ✔️ | Bug Warcall
- ✔️ | Create Panel Pterodactyl
- ✔️ | Full Fitur AI
- ✔️ | Setmenu (v1,v2,v3,v4)
- ✔️ | Dan Masih Banyak Lagi
- ---------


##
[![Group Chat](https://img.shields.io/badge/Owner%20BOT-25D366?style=for-the-badge&logo=whatsapp&logoColor=white)](https://chat.whatsapp.com/BkdLVSrEZa4EviQ7COGnpT) 
[![Bot](https://img.shields.io/badge/Bot%20Whatsapp-25D366?style=for-the-badge&logo=whatsapp&logoColor=white)](https://wa.me/6283150418588)


VnShoop | @callmevinz
AiBotzzSH | @SanjayaAds
WhatsApp Alvin : 083150418588
WhatsApp Jay : 089654057716

