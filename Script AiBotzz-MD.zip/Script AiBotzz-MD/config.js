const fs = require('fs')
const chalk = require('chalk')
const axios = require('axios');

// INGAT CUY INI CUMA SC HASIL RENAME ATAU RECODE YA

// Credit : @theJayy_
// Ori : @callmevinz

//=== Edit Disini 🔥
global.namabot = "AiBotzz-MD"
global.namaowner = "Sanjaya"
global.packname = "Sticker by"
global.creator = "SanjayaAds"
global.author = "AiBotzz-MD\n\nBot WhatsApp"
global.wm = "AiBotzz-MD"
global.syt = "https://www.youtube.com/@SanjayaAds"
global.sgc = "https://chat.whatsapp.com/BhLOaPSL3SKCw9QAnudLDw"
global.idgc = "120363250058335630@g.us"
global.email = "OwnerKuu@gmail.com"
global.sig = "https://Instagram.com/@Jayy_yete"
global.myweb = "https://shoplinks.to/AiBotzzSH"
global.footer_text = "© AiBotzz-MD"
global.owner = ['62896540577165']
global.gifin = "https://telegra.ph/file/0cf1c5039a2be1b66ef15.mp4"
global.thumb = "https://telegra.ph/file/6b25dc6f38b32804d7e59.jpg"
global.thumb2 = "https://telegra.ph/file/c74dda31793574f84070e.jpg"
global.mark = "https://telegra.ph/file/9b67cb5ed0ff661027366.jpg"
global.themeemoji = '🌐'

//=== Introgasi 🗿
global.umurowner = "Privat" // Terserah🗿
global.kelasowner = "Privat" // Terserah🗿
global.statusowner = "Jomblo" // Terserah
global.lakiapacewek = "Lanang" // Terserah
// Kalo mau gak diisi juga gak papa

//=== Payment 😋
global.qris = "https://telegra.ph/file/6a367b58ed14c5009179d.jpg"
global.pulsa = "https://telegra.ph/file/778689e2ede51180102ca.jpg"
global.dana = "0838-3140-9855"
global.gopay = "Gak ada"
global.rek = "7605-0101-8289-536"

//=== Nokos Token 😱
global.apikey ='8c3a5b302815a138d88148fa0c5916c0595bba50' 

//=== Apikey Nya 🔥
global.lol = 'GataDios'
global.lol = 'SGWN'
global.rose = 'Rs-putangina'
global.xyro = '5dRkJDWvIG'
global.APIs = {
xyro: "https://api.xyroinee.xyz",
popcat : 'https://api.popcat.xyz'
}
// APIKeys
global.APIKeys = {
"https://api.xyroinee.xyz": "5dRkJDWvIG"
}

//=== Gak Tau 🐦
global.pairingNumber = "6283831409855"
// Nomor whatsapp bot lu
global.prefix = ['-_-'] 
// Jangan diubah
global.tekspushcontact = "Izin Push" 
// Terserah
global.typemenu = "v6"
// Ini type menu nya
// v1 - v2 - v3 - v4 - v5 - v6
global.typeallmenu = "v1"
// Ini type allmenu nya
// v1 - v2 - v3 - v4 - v5 - v6
global.game = true
// False (Nonaktifin)
global.groupOnly = false 
// True (Mode grup)
global.privateOnly = false
// True (Mode grup)
global.antispam = true 
// False (Nonaktifin)
global.anticall = true
// False (Nonaktifin)
global.autoreadsw = true
// False (Nonaktifin)
global.antiBot = true
// False (Nonaktifin)
global.pengingat = true
// False (Nonaktifin)
global.autoTyping = true
// False (Nonaktifin)
global.autoBio = true
// False (Nonaktifin)
global.autoRestart = true
// False (Nonaktifin)
// AutoRestart Cocok Tuk Panel Butut
global.mess = {
 done: 'Sukses!',
 wait: 'Sedang diproses',
 admin: 'Fitur Khusus Admin grup!',
 botNotAdmin: 'Saya bukan Admin grup',
 owner: 'Fitur Khusus Owner!',
 group: 'Fitur Khusus Group!',
}

// Setting Game
global.gamewaktu = 60 // Game waktu
global.bmin = 1000 // Balance minimal 
global.bmax = 5000 // Balance maksimal
global.limit = 30 // Limit user

// Database Game
global.suit = {};
global.tictactoe = {};
global.petakbom = {};
global.kuis = {};
global.siapakahaku = {};
global.asahotak = {};
global.susunkata = {};
global.caklontong = {};
global.family100 = {};
global.tebaklirik = {};
global.tebaklagu = {};
global.tebakgambar = {};
global.tebakkimia = {};
global.tebakkata = {};
global.tebakkalimat = {};
global.tebakbendera = {};
global.tebakanime = {};
global.kuismath = {};

